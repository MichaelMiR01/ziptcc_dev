#pragma once
printf ("counter %d\n", __COUNTER__);
