#include <stdio.h>
#include <stdlib.h>	// atoi()

#define tcc_free free
#define tcc_malloc malloc
#define tcc_realloc realloc

#include "zipvfs.c"
//compress a folder recursively
#define MAX_PATH 1024
void zip_walk(struct zip_t *zip, const char *path) {
    DIR *dir;
    struct dirent *entry;
    char fullpath[MAX_PATH];
    struct stat s;
    printf("Scanning %s\n",path);

    memset(fullpath, 0, MAX_PATH);
    //printf ("Open Dir %s\n",path);
    dir = opendir(path);
    if (dir == NULL)
    {
         printf("Error: could not open directory %s %d\n", path,errno);
         return;             
    }    
    //printf ("Start reading...\n");
    while ((entry = readdir(dir))) {
      // skip "." and ".."
      //printf("buildpath for %s/%s\n",path, entry->d_name);
      if (!strcmp(entry->d_name, ".\0") || !strcmp(entry->d_name, "..\0"))
        continue;

      snprintf(fullpath, sizeof(fullpath), "%s/%s", path, entry->d_name);
      //printf("stat for %s\n",fullpath);
      stat(fullpath, &s);
      if (S_ISDIR(s.st_mode))
        zip_walk(zip, fullpath);
      else {
        zip_entry_open(zip, fullpath);
        zip_entry_fwrite(zip, fullpath);
        zip_entry_close(zip);
      }
    }

    closedir(dir);
}

// Create a new zip archive with default compression level.
void zip_folder (const char *zipname, const char *path) {
    struct zip_t *zip = zip_open(zipname, ZIP_DEFAULT_COMPRESSION_LEVEL, 'a');
    if(zip==NULL) {
        // create new
        zip = zip_open(zipname, ZIP_DEFAULT_COMPRESSION_LEVEL, 'w');
    }
    if(zip==NULL) {
        printf ("Error creating zip %s\n",zipname);
        return;
    }
    {
        zip_walk(zip, path);
    }
    zip_close(zip);
}

int main(int argc, char **argv) 
{
    char *zipname, *path;
	if (argc < 3) {
		printf("usage: zipper zipname directory_path\n"
			   "Compress path with subdirs into zip\n");
		return 1;
	}
		
	zipname=argv[1];
	path=argv[2];
	printf("Zipping %s into %s\n", path, zipname);
	zip_folder(zipname,path);
	printf("Ready\n");
	return 0;
}