struct nlist { /* table entry: */
    struct nlist *next; /* next entry in chain */
    char *name; /* defined name */
    void *defn; /* replacement text */
};

#define HASHSIZE 101
static struct nlist *thash_hashtab[HASHSIZE]; /* pointer table */

/* hash: form hash value for string s */
unsigned thash_hash(char *s)
{
    unsigned hashval;
    for (hashval = 0; *s != '\0'; s++)
      hashval = *s + 31 * hashval;
    return hashval % HASHSIZE;
}

/* lookup: look for s in hashtab */
struct nlist *thash_lookup(char *s)
{
    struct nlist *np;
    for (np = thash_hashtab[thash_hash(s)]; np != NULL; np = np->next)
        if (strcmp(s, np->name) == 0)
          return np; /* found */
    return NULL; /* not found */
}

void* thash_lookup_ptr(char *s)
{
    struct nlist *np;
    np=thash_lookup(s);
    if(np==NULL) return NULL;
    return np->defn;
}


/* thash_insert: put (name, defn) in hashtab */
struct nlist *thash_insert(char *name, void *defn)
{
    struct nlist *np;
    unsigned hashval;
    if ((np = thash_lookup(name)) == NULL) { /* not found */
        np = (struct nlist *) tcc_malloc(sizeof(*np));
        if (np == NULL || (np->name = tcc_strdup(name)) == NULL)
          return NULL;
        hashval = thash_hash(name);
        np->next = thash_hashtab[hashval];
        thash_hashtab[hashval] = np;
    } //else /* already there */
        //tcc_free((void *) np->defn); /*free previous defn */
    if ((np->defn = defn) == NULL)
       return NULL;
    return np;
}

int thash_delete(char *name)
{
    struct nlist *np,*op;
    if ((np = thash_lookup(name)) == NULL) return 0;
    thash_hashtab[thash_hash(name)]=NULL;
    tcc_free(np);
}


