# this will build libztcc_win32.a with mingw cross, to use in jim built with mingw-cross
# because gcc 9.2 and mingw-gcc 5.4 are incompatible
i686-w64-mingw32-gcc -o libtcc.o  -include ../tcc.h -include ../zipvfs/zipl_iomap.c  -c ../libtcc.c -DTCC_TARGET_PE -DTCC_TARGET_I386 -D_WIN32 -m32 -DLIBTCC_AS_DLL -DHAVE_ZIP_H -DONE_SOURCE"=1" -I.. -O2 -s
i686-w64-mingw32-ar cr libztcc_win32.a libtcc.o
i686-w64-mingw32-ranlib libztcc_win32.a
