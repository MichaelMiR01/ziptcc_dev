#!/bin/sh
topdir=..
tccdir=..
zipvfsdir=../zipvfs
zipvfssrc=zipvfs
win32=../win32
win32src=win32

mkdir $zipvfsdir
cp ./$zipvfssrc/*.tcl $zipvfsdir
cp ./$zipvfssrc/*.h   $zipvfsdir
cp ./$zipvfssrc/*.c   $zipvfsdir
cp ./$zipvfssrc/*.sh   $zipvfsdir


mkdir $zipvfsdir/lib
cp ./lib/* $zipvfsdir/lib
cp ./lib/* $tccdir/lib

mkdir $zipvfsdir/doc
mkdir $tccdir/doc
cp ./$zipvfssrc/doc/* $zipvfsdir/doc
cp ./$zipvfssrc/doc/* $tccdir/doc

cp ./$win32src/*.bat $win32
cp ./$win32src/*.h $win32
cp ./$win32src/replace_bat_for_wine.tcl $win32
#cp ./$win32src/VERSION $tccdir
version=`head $tccdir/VERSION`
at=$(stat -c '%.19y' $tccdir/README)
echo>$tccdir/VERSION "$version mob $at"
echo "Version $at"

cp -r ./linux/* $tccdir
cp -r ./include/* $tccdir/include/

if ! test -e ${tccdir}/win32/include/winapi/winsock2.h ; then
    echo "Copying missing winsock2 headers"
    cp ./win32winsock/* ${tccdir}/win32/include/winapi/
fi


